﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace helsinkigui3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<Helsinki> list = new List<Helsinki>();
            StreamWriter kiiras = new StreamWriter("helsinki2.txt");
         
            try
            {

                foreach (var sor in File.ReadAllLines("helsinki.txt"))
                {
                    list.Add(new Helsinki(sor));

                }
                


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            text1.Content = "A beolvasás sikeresen megtörtént";
            

            //3. Feladat

            Feladat_3.Content=($"Pontszerző helyezések száma: {list.Count}");

            //4.Feladat
            
            int arany, ezust, bronz, osszespont, helyezes;

            arany = 0;
            ezust = 0;
            bronz = 0;

            foreach (var elem in list) {
                if (elem.hely == 1) { arany++; }
                if (elem.hely == 2) { ezust++; }
                if (elem.hely == 3) { bronz++; }
            }
            Feladat_4.Content = $"Összesen: {arany + ezust + bronz}";

            //5. Feladat

            osszespont = 0;
            foreach(var elem in list) 
            {
                helyezes = elem.hely;
                switch (helyezes)
                {
                    case 1:
                        osszespont += 7;
                        break;
                    case 2:
                        osszespont += 5;
                        break;
                    case 3:
                        osszespont += 4;
                        break;
                    case 4:
                        osszespont += 3;
                        break;
                    case 5:
                        osszespont += 2;
                        break;
                    case 6:
                        osszespont += 1;
                        break;
                }
            }
            Feladat_5.Content = $"Olimpiai pontok száma: {osszespont}";

            //6. Feladat

            int uszas = 0;
            int torna = 0;

            foreach (var elem in list)
            {
                if (elem.hely < 4 && elem.sportag == "uszas") { uszas++; }
                if (elem.hely < 4 && elem.sportag == "torna") { torna++; }
            }
            if (uszas == torna) { Feladat_6.Content = ("Egyenlő volt az érmek száma."); }
            if (uszas < torna) { Feladat_6.Content = ("Torna sportágban szereztek több érmet."); }
            if (uszas > torna) { Feladat_6.Content = ("Úszás sportágban szereztek több érmet."); }

            //7. Feladat

            try
            {
                foreach (var elem in list)
                {
                    kiiras.WriteLine(elem.Eredmeny());
                }
                kiiras.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            Feladat_7.Content = "A feljbeírás megtörtént.";

            //8. Feladat

            int max = list[0].db;

            foreach(var elem in list)
            {
                if (elem.db > max) max = elem.db;
            }
            foreach (var elem in list)
            {
                if (elem.db == max)
                {
                    Feladat_81.Content = $"Sportág: {elem.sportag}";
                    Feladat_82.Content += $"Versenyszám: {elem.versenyszam}";
                }
            }
            Feladat_83.Content += $"Sportolók száma: {max}";


        }
    }
}
