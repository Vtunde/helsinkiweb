﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helsinkigui3
{
    internal class Helsinki
    {
        

            public int hely { get; private set; }
            public int db { get; private set; }
            public string sportag { get; private set; }
            public string versenyszam { get; private set; }
            public int pontszam { get; private set; }




        public Helsinki(string egysor)
        {
            string[] seged = egysor.Split(' ');
            hely = int.Parse(seged[0]);
            db = int.Parse(seged[1]);
            sportag = seged[2];
            versenyszam = seged[3];
        }


        public override string ToString() => $"hely= {hely}, db= {db}, sportag= {sportag}, versenyszam= {versenyszam}, pontszam= {pontszam}";

        public String Eredmeny()
        {
            String nev = sportag;
            if (sportag.Equals("kajakkenu"))
            {
                nev = "kajak-kenu";
            }

            return $"{hely} {db} {pontszam} {nev} {versenyszam}";
        }

       


    }

}

