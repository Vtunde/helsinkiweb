/*
document.getElementById('3gomb').onclick=function() {

}
*/

/*function fajlOlvaso(){
    var selected=document.getElementById("fajl").files;
    console.log(selected);
}
*/
/*
let fajl=document.getElementById('fajl');
let fajlmutato= document.getElementById('fajlmutato');

fajl.addEventListener('change', ()=>{
    let fr= new FileReader();
    fr.onload=function() {
        fajlmutato.innerHTML=fr.result;
        console.log(fajlmutato)
    }

});
*/
/*
fileInput.addEventListener('change', ()=> {
    const fr=new FileReader();
    fr.readAsText(fileInput.files[0]);
    fr.addEventListener('load',()=> {
        const txt=fr.result;
        txt.split()
    })
})
*/


let file='helsinki.txt';
let sorok=[];
let sorszam=0;
let objektumok=[];

document.getElementById('gomb').onclick=function(){
    fetch(file)
    .then(x => x.text())
    .then(y => darabol(y));
}
 
function darabol(filetartalom){
 
    console.log(filetartalom);
    sorok = filetartalom.split('\n');
    

 
    for(sor of sorok){
 
        console.log(sor);
        adatok = sor.split(' ');
        console.log(adatok);
        let sema= {
            helyezes:0,
            versSzam:0,
            sportag:'',
            versenyszam:'',
        }
  
        sema.helyezes=Number(adatok[0]);
        sema.versSzam=Number(adatok[1]);
        sema.sportag=adatok[2];
        sema.versenyszam=adatok[3];
    
        objektumok.push(sema);
        console.log(sema);
    }
 
 
}

document.getElementById('3gomb').onclick=function(){
   
sorszam=sorok.length;
document.getElementById('kiir3').innerHTML=
`
<h2>${sorszam}</h2>
`
}

document.getElementById('4gomb').onclick=function(){
   
    let arany=0;
    let ezust=0;
    let bronz=0;
    let osszesen=0;

    for (o of objektumok) {
        if (o.helyezes ==1){
            arany++;
        } }
    for (o of objektumok){
        if (o.helyezes ==2){
            ezust++; 
        }}
    
     
   for (o of objektumok) {
        if (o.helyezes ==3){
            bronz++;
    }}


    document.getElementById('kiir4').innerHTML=
    `
    <h2> Arany=${arany}</h2>
    <h2> Ezüst=${ezust}</h2>
    <h2> Bronz=${bronz}</h2>
    `
    }
    



