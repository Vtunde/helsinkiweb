﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace helsinkigui3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<Helsinki> list = new List<Helsinki>();
         
            try
            {

                foreach (var sor in File.ReadAllLines("helsinki.txt"))
                {
                    list.Add(new Helsinki(sor));
                }
                foreach (var elem in list)
                {
                  text1.Content = elem;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            //3. Feladat
            
            Feladat_3.Content=($"Pontszerző helyezések száma: {list.Count}");

            //4.Feladat
            
            int arany, ezust, bronz, osszespont, helyezes;

            arany = 0;
            ezust = 0;
            bronz = 0;

            foreach (var elem in list) {
                if (elem.hely == 1) { arany++; }
                if (elem.hely == 2) { ezust++; }
                if (elem.hely == 3) { bronz++; }
            }
            Feladat_4.Content = ("Összesen: {0}", arany + ezust + bronz);

            //5. Feladat

            Console.WriteLine("5. feladat:");
            osszespont = 0;
            foreach(var elem in list) 
            {
                helyezes = elem.hely;
                switch (helyezes)
                {
                    case 1:
                        osszespont += 7;
                        break;
                    case 2:
                        osszespont += 5;
                        break;
                    case 3:
                        osszespont += 4;
                        break;
                    case 4:
                        osszespont += 3;
                        break;
                    case 5:
                        osszespont += 2;
                        break;
                    case 6:
                        osszespont += 1;
                        break;
                }
            }
            Feladat_4.Content = ($"Olimpiai pontok száma: {osszespont}");

            //6. Feladat



        }
    }
}
